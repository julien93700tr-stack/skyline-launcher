package com.example.neonlauncher

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.KeyEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

/** Launcher = un WebView plein écran qui affiche assets/dashboard.html, avec un pont "Android" pour les applis. */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("dash", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#04060C"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/dashboard.html")
        web.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.Dash&&Dash.resume&&Dash.resume()", null)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            web.evaluateJavascript("window.Dash&&Dash.back()", null)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("window.Dash&&Dash.back()", null)
    }

    private fun intentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    inner class Bridge {
        @JavascriptInterface
        fun favorites(): String {
            val saved = prefs.getString("fav", null)
            val pkgs: List<String> = if (saved != null) {
                val a = JSONArray(saved)
                (0 until a.length()).map { a.getString(it) }
            } else {
                listOf(
                    "com.netflix.ninja", "com.amazon.amazonvideo.livingroom", "com.spotify.tv.android",
                    "com.google.android.youtube.tv", "com.liskovsoft.smarttubetv", "com.disney.disneyplus"
                )
            }
            val arr = JSONArray()
            for (p in pkgs) {
                if (intentFor(p) == null) continue
                val label = try {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString()
                } catch (e: Exception) {
                    continue
                }
                arr.put(JSONObject().put("n", label).put("p", p))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            var list = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0
            )
            if (list.isEmpty()) {
                list = pm.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                )
            }
            val arr = JSONArray()
            list.filter { it.activityInfo.packageName != packageName }
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
                .forEach { arr.put(JSONObject().put("n", it.second).put("p", it.first)) }
            return arr.toString()
        }

        @JavascriptInterface
        fun setFav(json: String) {
            prefs.edit().putString("fav", json).apply()
        }

        @JavascriptInterface
        fun launch(pkg: String) {
            val i = intentFor(pkg) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }

        @JavascriptInterface
        fun settings() {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
            }
        }

        @JavascriptInterface
        fun sys(): String {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong / 1e9
            val free = st.availableBlocksLong * st.blockSizeLong / 1e9
            val bt = try {
                BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
            } catch (e: Exception) {
                false
            }
            return JSONObject().put("bt", bt).put("free", free).put("total", Math.round(total)).toString()
        }
    }
}
