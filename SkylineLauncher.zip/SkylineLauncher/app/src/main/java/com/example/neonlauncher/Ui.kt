package com.example.neonlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

object Ui {

    fun px(ctx: Context, dp: Int): Int = (dp * ctx.resources.displayMetrics.density).toInt()

    private fun shape(
        ctx: Context, oval: Boolean, radiusDp: Float, fill: Int, strokeDp: Float, stroke: Int
    ): GradientDrawable {
        val d = ctx.resources.displayMetrics.density
        val g = GradientDrawable()
        g.shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        if (!oval) g.cornerRadius = maxOf(0f, radiusDp) * d
        g.setColor(fill)
        if (strokeDp > 0f) g.setStroke(maxOf(1, (strokeDp * d).toInt()), stroke)
        return g
    }

    /** Fond d'une carte (widget) selon le style choisi. */
    fun card(ctx: Context): Drawable =
        shape(ctx, false, Prefs.CARD_RADIUS[Prefs.radius(ctx)], Prefs.CARD_COLORS[Prefs.cardStyle(ctx)], 1f, 0x22FFFFFF)

    fun disc(ctx: Context, color: Int): Drawable = shape(ctx, true, 0f, color, 0f, 0)

    fun roundRect(ctx: Context, color: Int, radiusDp: Float): Drawable =
        shape(ctx, false, radiusDp, color, 0f, 0)

    /**
     * Fond avec contour lumineux quand l'élément est sélectionné :
     * trois anneaux concentriques (halo doux -> trait net) dans une bande de [bandDp].
     */
    fun focusDrawable(
        ctx: Context, accent: Int, radiusDp: Float, oval: Boolean,
        bandDp: Float, fill: Int, fillInsetDp: Float
    ): Drawable {
        val d = ctx.resources.displayMetrics.density
        fun alpha(a: Int) = (accent and 0x00FFFFFF) or (a shl 24)
        fun inset(l: LayerDrawable, i: Int, dp: Float) {
            val p = (dp * d).toInt()
            l.setLayerInset(i, p, p, p, p)
        }

        val plain = LayerDrawable(arrayOf<Drawable>(shape(ctx, oval, radiusDp - fillInsetDp, fill, 0f, 0)))
        inset(plain, 0, fillInsetDp)

        val b = bandDp
        val focused = LayerDrawable(
            arrayOf<Drawable>(
                shape(ctx, oval, radiusDp - fillInsetDp, fill, 0f, 0),
                shape(ctx, oval, radiusDp - b * 0.50f, Color.TRANSPARENT, b, alpha(0x22)),
                shape(ctx, oval, radiusDp - b * 0.67f, Color.TRANSPARENT, b * 0.66f, alpha(0x66)),
                shape(ctx, oval, radiusDp - b * 0.83f, Color.TRANSPARENT, b * 0.34f, accent or (0xFF shl 24))
            )
        )
        inset(focused, 0, fillInsetDp)
        inset(focused, 1, b * 0.50f)
        inset(focused, 2, b * 0.67f)
        inset(focused, 3, b * 0.83f)

        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_focused), focused)
        sl.addState(intArrayOf(), plain)
        return sl
    }

    /** Animation de clic : léger "écrasement" puis rebond, puis action. */
    fun press(view: View, base: Float, anim: Int, then: () -> Unit) {
        if (anim == 2) {
            then()
            return
        }
        view.animate().cancel()
        view.animate().scaleX(base * 0.9f).scaleY(base * 0.9f).setDuration(80).withEndAction {
            view.animate().scaleX(base).scaleY(base).setDuration(140)
                .setInterpolator(OvershootInterpolator(2.5f))
                .withEndAction { then() }.start()
        }.start()
    }

    fun focusScale(view: View, focused: Boolean, scale: Float, anim: Int) {
        val s = if (focused) scale else 1f
        if (anim == 2) {
            view.scaleX = s
            view.scaleY = s
        } else {
            view.animate().scaleX(s).scaleY(s).setDuration(140).start()
        }
    }

    /** Prépare une tuile d'application (banderole ou icône) et renvoie la zone focusable. */
    fun setupTile(
        ctx: Context, item: View, name: String, drawable: Drawable?, banner: Boolean,
        showLabel: Boolean, onFocus: ((Boolean) -> Unit)?, onClick: (View) -> Unit
    ): View {
        val anim = Prefs.anim(ctx)
        val accent = Prefs.accent(ctx)
        val si = Prefs.tileSize(ctx)
        val r = Prefs.TILE_RADIUS[Prefs.radius(ctx)]

        val tile = item.findViewById<View>(R.id.tile)
        val card = item.findViewById<FrameLayout>(R.id.card)
        val img = item.findViewById<ImageView>(R.id.icon)
        val label = item.findViewById<TextView>(R.id.label)

        val lp = card.layoutParams
        lp.width = px(ctx, Prefs.TILE_W[si])
        lp.height = px(ctx, Prefs.TILE_H[si])
        card.layoutParams = lp
        card.background = shape(ctx, false, r, 0xFF2A2A32.toInt(), 0f, 0)
        card.clipToOutline = true
        card.outlineProvider = ViewOutlineProvider.BACKGROUND

        tile.background = focusDrawable(ctx, accent, r + 6f, false, 6f, Color.TRANSPARENT, 0f)

        img.setImageDrawable(drawable)
        if (banner) {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setPadding(0, 0, 0, 0)
        } else {
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            val p = px(ctx, Prefs.TILE_H[si] / 7)
            img.setPadding(p, p, p, p)
        }

        // Logos : couleur / noir et blanc / noir et blanc + couleur à la sélection
        val iconMode = Prefs.iconStyle(ctx)
        val gray = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        if (iconMode == 0) img.clearColorFilter() else img.setColorFilter(gray)

        label.text = name
        label.maxWidth = px(ctx, Prefs.TILE_W[si] + 12)
        label.visibility = if (showLabel) View.VISIBLE else View.INVISIBLE

        tile.setOnFocusChangeListener { v, focused ->
            focusScale(v, focused, 1.1f, anim)
            if (!showLabel) label.visibility = if (focused) View.VISIBLE else View.INVISIBLE
            if (iconMode == 2) {
                if (focused) img.clearColorFilter() else img.setColorFilter(gray)
            }
            onFocus?.invoke(focused)
        }
        tile.setOnClickListener { v -> press(v, if (v.isFocused) 1.1f else 1f, anim) { onClick(v) } }
        return tile
    }

    fun transparent(): Drawable = ColorDrawable(Color.TRANSPARENT)
}
