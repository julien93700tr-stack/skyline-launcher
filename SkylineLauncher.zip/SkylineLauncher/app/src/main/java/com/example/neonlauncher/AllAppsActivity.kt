package com.example.neonlauncher

import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppEntry(val label: String, val icon: Drawable, val component: ComponentName)

class AllAppsActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_apps)
        recycler = findViewById(R.id.apps)
        recycler.layoutManager = GridLayoutManager(this, 7)
    }

    override fun onResume() {
        super.onResume()
        recycler.adapter = AppAdapter(loadApps()) { launch(it) }
        recycler.post { recycler.getChildAt(0)?.requestFocus() }
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var list = pm.queryIntentActivities(intent, 0)
        if (list.isEmpty()) {
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            list = pm.queryIntentActivities(intent, 0)
        }
        return list
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppEntry(
                    it.loadLabel(pm).toString(),
                    it.loadIcon(pm),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(app: AppEntry) {
        startActivity(Intent(Intent.ACTION_MAIN).apply {
            component = app.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
}

class AppAdapter(
    private val items: List<AppEntry>,
    private val onClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
        holder.itemView.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
    }

    override fun getItemCount() = items.size
}
