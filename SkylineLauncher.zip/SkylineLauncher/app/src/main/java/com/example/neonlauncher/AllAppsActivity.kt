package com.example.neonlauncher

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppEntry(val label: String, val drawable: Drawable?, val banner: Boolean, val component: ComponentName)

class AllAppsActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_apps)
        recycler = findViewById(R.id.apps)
        val tileW = Prefs.TILE_W[Prefs.tileSize(this)]
        val cols = maxOf(3, (resources.configuration.screenWidthDp - 96) / (tileW + 24))
        recycler.layoutManager = GridLayoutManager(this, cols)
    }

    override fun onResume() {
        super.onResume()
        recycler.adapter = AppAdapter(loadApps()) { app, v -> launch(app, v) }
        recycler.post { recycler.getChildAt(0)?.requestFocus() }
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var list = pm.queryIntentActivities(intent, 0)
        if (list.isEmpty()) {
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            list = pm.queryIntentActivities(intent, 0)
        }
        return list
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val banner: Drawable? = it.activityInfo.loadBanner(pm)
                    ?: it.activityInfo.applicationInfo.loadBanner(pm)
                AppEntry(
                    it.loadLabel(pm).toString(),
                    banner ?: it.loadIcon(pm),
                    banner != null,
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(app: AppEntry, from: View) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            component = app.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            if (Prefs.anim(this) == 0) {
                val o = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(i, o.toBundle())
            } else {
                startActivity(i)
            }
        } catch (e: Exception) {
        }
    }
}

class AppAdapter(
    private val items: List<AppEntry>,
    private val onClick: (AppEntry, View) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_fav, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        Ui.setupTile(
            holder.itemView.context, holder.itemView, app.label, app.drawable, app.banner,
            true, null
        ) { v -> onClick(app, v) }
    }

    override fun getItemCount() = items.size
}
