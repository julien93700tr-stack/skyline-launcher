package com.example.neonlauncher

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import java.io.File

/** Tous les réglages modifiables depuis la TV (menu "Personnaliser"). */
object Prefs {
    val DIM_NAMES = arrayOf("Aucun", "Léger", "Moyen", "Fort")
    val DIM_LEVELS = floatArrayOf(0f, 0.25f, 0.5f, 0.75f)
    val CLOCK_NAMES = arrayOf("Petite", "Moyenne", "Grande")
    val CLOCK_SIZES = intArrayOf(150, 190, 230)

    // Applis du bas par défaut (le premier package installé de chaque ligne est utilisé)
    private val DEFAULT_APPS = listOf(
        listOf("com.google.android.youtube.tv", "com.liskovsoft.smarttubetv"),
        listOf("com.netflix.ninja"),
        listOf("com.amazon.amazonvideo.livingroom"),
        listOf("com.disney.disneyplus"),
        listOf("com.spotify.tv.android")
    )

    private fun sp(c: Context) = c.getSharedPreferences("skyline", Context.MODE_PRIVATE)

    fun wallpaper(c: Context): String = sp(c).getString("wallpaper", "default") ?: "default"
    fun setWallpaper(c: Context, v: String) = sp(c).edit().putString("wallpaper", v).apply()

    fun dim(c: Context): Int = sp(c).getInt("dim", 2).coerceIn(0, DIM_LEVELS.lastIndex)
    fun setDim(c: Context, i: Int) = sp(c).edit().putInt("dim", i).apply()

    fun clockIndex(c: Context): Int = sp(c).getInt("clock", 1).coerceIn(0, CLOCK_SIZES.lastIndex)
    fun setClockIndex(c: Context, i: Int) = sp(c).edit().putInt("clock", i).apply()

    fun city(c: Context): String = sp(c).getString("city", "Paris") ?: "Paris"
    fun lat(c: Context): Double = sp(c).getString("lat", "48.8566")?.toDoubleOrNull() ?: 48.8566
    fun lon(c: Context): Double = sp(c).getString("lon", "2.3522")?.toDoubleOrNull() ?: 2.3522
    fun setCity(c: Context, name: String, lat: Double, lon: Double) =
        sp(c).edit().putString("city", name).putString("lat", lat.toString())
            .putString("lon", lon.toString()).apply()

    fun showCalendar(c: Context) = sp(c).getBoolean("showCal", true)
    fun showWeather(c: Context) = sp(c).getBoolean("showWeather", true)
    fun setShow(c: Context, calendar: Boolean, weather: Boolean) =
        sp(c).edit().putBoolean("showCal", calendar).putBoolean("showWeather", weather).apply()

    /** null = jamais personnalisé -> liste par défaut */
    fun favorites(c: Context): List<String>? {
        val s = sp(c).getString("favs", null) ?: return null
        return s.split(",").filter { it.isNotBlank() }
    }
    fun setFavorites(c: Context, l: List<String>) =
        sp(c).edit().putString("favs", l.joinToString(",")).apply()

    fun defaultFavorites(pm: PackageManager): List<String> =
        DEFAULT_APPS.mapNotNull { pkgs ->
            pkgs.firstOrNull {
                pm.getLeanbackLaunchIntentForPackage(it) != null || pm.getLaunchIntentForPackage(it) != null
            }
        }

    fun reset(c: Context) {
        sp(c).edit().clear().apply()
        File(c.filesDir, "wallpaper_custom.jpg").delete()
    }
}

object Wallpapers {
    val CHOICES = listOf(
        "default" to "Ville de nuit (par défaut)",
        "night" to "Dégradé nuit",
        "aurora" to "Dégradé aurore",
        "black" to "Noir total"
    )

    fun label(key: String): String =
        if (key == "custom") "Mon image" else CHOICES.firstOrNull { it.first == key }?.second ?: "Par défaut"

    fun show(c: Context, view: ImageView, key: String) {
        when (key) {
            "custom" -> {
                val f = File(c.filesDir, "wallpaper_custom.jpg")
                val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
                if (bmp != null) view.setImageBitmap(bmp) else view.setImageResource(R.drawable.wallpaper)
            }
            "night" -> view.setImageDrawable(
                GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0xFF0B1330.toInt(), 0xFF1B2A5C.toInt(), 0xFF000000.toInt())
                )
            )
            "aurora" -> view.setImageDrawable(
                GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
                )
            )
            "black" -> view.setImageDrawable(ColorDrawable(Color.BLACK))
            else -> view.setImageResource(R.drawable.wallpaper)
        }
    }
}
