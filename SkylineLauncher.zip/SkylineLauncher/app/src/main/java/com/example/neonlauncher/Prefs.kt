package com.example.neonlauncher

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.widget.ImageView
import java.io.File

data class Shortcut(val key: String, val icon: String, val label: String, val action: String)

/** Tous les réglages modifiables depuis la TV (menu "Personnaliser"). */
object Prefs {
    val DIM_NAMES = arrayOf("Aucun", "Léger", "Moyen", "Fort")
    val DIM_LEVELS = floatArrayOf(0f, 0.25f, 0.5f, 0.75f)

    val CLOCK_NAMES = arrayOf("Petite", "Moyenne", "Grande")
    val CLOCK_SIZES = intArrayOf(140, 180, 210)

    val ACCENT_NAMES = arrayOf("Blanc", "Cyan", "Rose", "Orange", "Vert", "Violet")
    val ACCENT_COLORS = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt(), 0xFFFF4DB8.toInt(),
        0xFFFF9F43.toInt(), 0xFF3DFF8B.toInt(), 0xFFB388FF.toInt()
    )

    val RADIUS_NAMES = arrayOf("Carré", "Doux", "Arrondi", "Très arrondi")
    val TILE_RADIUS = floatArrayOf(4f, 10f, 16f, 24f)
    val CARD_RADIUS = floatArrayOf(6f, 16f, 24f, 32f)

    val CARD_NAMES = arrayOf("Transparent", "Verre", "Sombre", "Opaque")
    val CARD_COLORS = intArrayOf(0x14FFFFFF, 0x2EFFFFFF, 0x66000000, 0xE6101018.toInt())

    val TILE_SIZE_NAMES = arrayOf("Petites", "Moyennes", "Grandes")
    val TILE_W = intArrayOf(112, 132, 160)
    val TILE_H = intArrayOf(63, 74, 90)

    val ANIM_NAMES = arrayOf("Complètes", "Légères", "Désactivées")
    val ICON_NAMES = arrayOf("Couleur", "Noir et blanc", "Noir et blanc, couleur à la sélection")
    val TEMP_UNITS = arrayOf("Celsius (°C)", "Fahrenheit (°F)")

    val SHORTCUTS = listOf(
        Shortcut("wifi", "📶", "Wi-Fi", Settings.ACTION_WIFI_SETTINGS),
        Shortcut("bluetooth", "🎧", "Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
        Shortcut("sound", "🔊", "Son", Settings.ACTION_SOUND_SETTINGS),
        Shortcut("display", "📺", "Affichage", Settings.ACTION_DISPLAY_SETTINGS),
        Shortcut("network", "🌐", "Réseau", Settings.ACTION_WIRELESS_SETTINGS),
        Shortcut("apps", "📦", "Applications", Settings.ACTION_APPLICATION_SETTINGS),
        Shortcut("storage", "💾", "Stockage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        Shortcut("date", "🕒", "Date et heure", Settings.ACTION_DATE_SETTINGS),
        Shortcut("access", "♿", "Accessibilité", Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Shortcut("settings", "⚙️", "Réglages", Settings.ACTION_SETTINGS)
    )
    private const val DEFAULT_SHORTCUTS = "wifi,bluetooth,sound,display,settings"

    val WIDGETS = listOf(
        "calendar" to "Calendrier",
        "weather" to "Météo",
        "shortcuts" to "Raccourcis",
        "countdown" to "Compte à rebours",
        "storage" to "Stockage"
    )
    private const val DEFAULT_WIDGETS = "calendar,weather,shortcuts,storage"

    // Applis du bas par défaut (le premier package installé de chaque ligne est utilisé)
    private val DEFAULT_APPS = listOf(
        listOf("com.google.android.youtube.tv", "com.liskovsoft.smarttubetv"),
        listOf("com.netflix.ninja"),
        listOf("com.amazon.amazonvideo.livingroom"),
        listOf("com.disney.disneyplus"),
        listOf("com.spotify.tv.android")
    )

    private fun sp(c: Context) = c.getSharedPreferences("skyline", Context.MODE_PRIVATE)
    private fun idx(c: Context, key: String, def: Int, max: Int) =
        sp(c).getInt(key, def).coerceIn(0, max)

    // --- Apparence ---
    fun wallpaper(c: Context): String = sp(c).getString("wallpaper", "default") ?: "default"
    fun setWallpaper(c: Context, v: String) = sp(c).edit().putString("wallpaper", v).apply()

    fun dim(c: Context) = idx(c, "dim", 2, DIM_LEVELS.lastIndex)
    fun setDim(c: Context, i: Int) = sp(c).edit().putInt("dim", i).apply()

    fun clockIndex(c: Context) = idx(c, "clock", 1, CLOCK_SIZES.lastIndex)
    fun setClockIndex(c: Context, i: Int) = sp(c).edit().putInt("clock", i).apply()

    fun clock24(c: Context) = sp(c).getBoolean("clock24", true)
    fun setClock24(c: Context, v: Boolean) = sp(c).edit().putBoolean("clock24", v).apply()

    fun accentIndex(c: Context) = idx(c, "accent", 0, ACCENT_COLORS.lastIndex)
    fun accent(c: Context) = ACCENT_COLORS[accentIndex(c)]
    fun setAccent(c: Context, i: Int) = sp(c).edit().putInt("accent", i).apply()

    fun radius(c: Context) = idx(c, "radius", 2, TILE_RADIUS.lastIndex)
    fun setRadius(c: Context, i: Int) = sp(c).edit().putInt("radius", i).apply()

    fun cardStyle(c: Context) = idx(c, "card", 1, CARD_COLORS.lastIndex)
    fun setCardStyle(c: Context, i: Int) = sp(c).edit().putInt("card", i).apply()

    fun tileSize(c: Context) = idx(c, "tileSize", 1, TILE_W.lastIndex)
    fun setTileSize(c: Context, i: Int) = sp(c).edit().putInt("tileSize", i).apply()

    fun iconStyle(c: Context) = idx(c, "iconStyle", 1, 2)
    fun setIconStyle(c: Context, i: Int) = sp(c).edit().putInt("iconStyle", i).apply()

    fun anim(c: Context) = idx(c, "anim", 0, 2)
    fun setAnim(c: Context, i: Int) = sp(c).edit().putInt("anim", i).apply()

    // --- Contenu ---
    fun userName(c: Context): String = sp(c).getString("userName", "") ?: ""
    fun setUserName(c: Context, v: String) = sp(c).edit().putString("userName", v).apply()

    fun city(c: Context): String = sp(c).getString("city", "Paris") ?: "Paris"
    fun lat(c: Context): Double = sp(c).getString("lat", "48.8566")?.toDoubleOrNull() ?: 48.8566
    fun lon(c: Context): Double = sp(c).getString("lon", "2.3522")?.toDoubleOrNull() ?: 2.3522
    fun setCity(c: Context, name: String, lat: Double, lon: Double) =
        sp(c).edit().putString("city", name).putString("lat", lat.toString())
            .putString("lon", lon.toString()).apply()

    fun tempUnit(c: Context) = idx(c, "tempUnit", 0, 1)
    fun setTempUnit(c: Context, i: Int) = sp(c).edit().putInt("tempUnit", i).apply()

    fun widgets(c: Context): Set<String> =
        (sp(c).getString("widgets", DEFAULT_WIDGETS) ?: "").split(",").filter { it.isNotBlank() }.toSet()
    fun setWidgets(c: Context, s: Set<String>) =
        sp(c).edit().putString("widgets", s.joinToString(",")).apply()

    fun shortcuts(c: Context): List<String> =
        (sp(c).getString("shortcuts", DEFAULT_SHORTCUTS) ?: "").split(",").filter { it.isNotBlank() }
    fun setShortcuts(c: Context, l: List<String>) =
        sp(c).edit().putString("shortcuts", l.joinToString(",")).apply()

    fun cdTitle(c: Context): String = sp(c).getString("cdTitle", "") ?: ""
    fun cdDate(c: Context): Long = sp(c).getLong("cdDate", 0L)
    fun setCountdown(c: Context, title: String, date: Long) =
        sp(c).edit().putString("cdTitle", title).putLong("cdDate", date).apply()

    /** null = jamais personnalisé -> liste par défaut */
    fun favorites(c: Context): List<String>? {
        val s = sp(c).getString("favs", null) ?: return null
        return s.split(",").filter { it.isNotBlank() }
    }
    fun setFavorites(c: Context, l: List<String>) =
        sp(c).edit().putString("favs", l.joinToString(",")).apply()

    fun defaultFavorites(pm: PackageManager): List<String> =
        DEFAULT_APPS.mapNotNull { pkgs ->
            pkgs.firstOrNull {
                pm.getLeanbackLaunchIntentForPackage(it) != null || pm.getLaunchIntentForPackage(it) != null
            }
        }

    fun reset(c: Context) {
        sp(c).edit().clear().apply()
        File(c.filesDir, "wallpaper_custom.jpg").delete()
    }
}

object Wallpapers {
    val CHOICES = listOf(
        "default" to "Ville de nuit (par défaut)",
        "night" to "Dégradé nuit",
        "aurora" to "Dégradé aurore",
        "dusk" to "Dégradé crépuscule",
        "black" to "Noir total"
    )

    fun label(key: String): String =
        if (key == "custom") "Mon image" else CHOICES.firstOrNull { it.first == key }?.second ?: "Par défaut"

    private fun grad(vararg colors: Long) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        IntArray(colors.size) { colors[it].toInt() }
    )

    fun show(c: Context, view: ImageView, key: String) {
        when (key) {
            "custom" -> {
                val f = File(c.filesDir, "wallpaper_custom.jpg")
                val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
                if (bmp != null) view.setImageBitmap(bmp) else view.setImageResource(R.drawable.wallpaper)
            }
            "night" -> view.setImageDrawable(grad(0xFF0B1330, 0xFF1B2A5C, 0xFF000000))
            "aurora" -> view.setImageDrawable(grad(0xFF0F2027, 0xFF203A43, 0xFF2C5364))
            "dusk" -> view.setImageDrawable(grad(0xFF1A0B2E, 0xFF4A1942, 0xFF0B0B14))
            "black" -> view.setImageDrawable(ColorDrawable(Color.BLACK))
            else -> view.setImageResource(R.drawable.wallpaper)
        }
    }
}
