package com.example.neonlauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private val refreshers = mutableListOf<() -> Unit>()
    private lateinit var list: LinearLayout
    private var firstRow: View? = null

    private val pickDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }
    private val pickGet = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }

    private fun dp(v: Int) = Ui.px(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun refreshAll() = refreshers.forEach { it() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundResource(R.drawable.bg_gradient)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(48), dp(24), dp(48), dp(28))
        scroll.addView(list)
        setContentView(scroll)

        val title = TextView(this)
        title.text = "Personnaliser"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        list.addView(title)
        val hint = TextView(this)
        hint.text = "OK pour modifier un réglage · Retour pour revenir à l'accueil"
        hint.setTextColor(0x99FFFFFF.toInt())
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        hint.setPadding(0, dp(4), 0, dp(6))
        list.addView(hint)

        header("APPARENCE")
        addRow("Fond d'écran", { Wallpapers.label(Prefs.wallpaper(this)) }) { chooseWallpaper() }
        addRow("Assombrissement du fond", { Prefs.DIM_NAMES[Prefs.dim(this)] }) {
            chooseOne("Assombrissement du fond", Prefs.DIM_NAMES, Prefs.dim(this)) { Prefs.setDim(this, it) }
        }
        addRow("Couleur d'accent et contour lumineux", { Prefs.ACCENT_NAMES[Prefs.accentIndex(this)] }) {
            chooseOne("Couleur d'accent", Prefs.ACCENT_NAMES, Prefs.accentIndex(this)) { Prefs.setAccent(this, it) }
        }
        addRow("Coins", { Prefs.RADIUS_NAMES[Prefs.radius(this)] }) {
            chooseOne("Coins", Prefs.RADIUS_NAMES, Prefs.radius(this)) { Prefs.setRadius(this, it) }
        }
        addRow("Logos des applications", { Prefs.ICON_NAMES[Prefs.iconStyle(this)] }) {
            chooseOne("Logos des applications", Prefs.ICON_NAMES, Prefs.iconStyle(this)) { Prefs.setIconStyle(this, it) }
        }
        addRow("Style des cartes", { Prefs.CARD_NAMES[Prefs.cardStyle(this)] }) {
            chooseOne("Style des cartes", Prefs.CARD_NAMES, Prefs.cardStyle(this)) { Prefs.setCardStyle(this, it) }
        }
        addRow("Taille des tuiles d'applications", { Prefs.TILE_SIZE_NAMES[Prefs.tileSize(this)] }) {
            chooseOne("Taille des tuiles", Prefs.TILE_SIZE_NAMES, Prefs.tileSize(this)) { Prefs.setTileSize(this, it) }
        }
        addRow("Taille de l'heure", { Prefs.CLOCK_NAMES[Prefs.clockIndex(this)] }) {
            chooseOne("Taille de l'heure", Prefs.CLOCK_NAMES, Prefs.clockIndex(this)) { Prefs.setClockIndex(this, it) }
        }
        addRow("Format de l'heure", { if (Prefs.clock24(this)) "24 heures" else "12 heures" }) {
            chooseOne("Format de l'heure", arrayOf("24 heures", "12 heures"), if (Prefs.clock24(this)) 0 else 1) {
                Prefs.setClock24(this, it == 0)
            }
        }
        addRow("Animations", { Prefs.ANIM_NAMES[Prefs.anim(this)] }) {
            chooseOne("Animations", Prefs.ANIM_NAMES, Prefs.anim(this)) { Prefs.setAnim(this, it) }
        }

        header("CONTENU")
        addRow("Prénom (message d'accueil)", { Prefs.userName(this).ifBlank { "Non défini" } }) { chooseName() }
        addRow("Widgets affichés", {
            val w = Prefs.widgets(this)
            Prefs.WIDGETS.filter { it.first in w }.joinToString(", ") { it.second }.ifEmpty { "Aucun" }
        }) { chooseWidgets() }
        addRow("Raccourcis", { "${Prefs.shortcuts(this).size} raccourci(s)" }) { chooseShortcuts() }
        addRow("Applications du bas", {
            val n = (Prefs.favorites(this) ?: Prefs.defaultFavorites(packageManager)).size
            "$n application(s)"
        }) { chooseApps() }
        addRow("Ville de la météo", { Prefs.city(this) }) { chooseCity() }
        addRow("Unité de température", { Prefs.TEMP_UNITS[Prefs.tempUnit(this)] }) {
            chooseOne("Unité de température", Prefs.TEMP_UNITS, Prefs.tempUnit(this)) { Prefs.setTempUnit(this, it) }
        }
        addRow("Compte à rebours", {
            if (Prefs.cdDate(this) == 0L) "Non défini" else {
                val d = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(Prefs.cdDate(this)))
                val t = Prefs.cdTitle(this)
                if (t.isBlank()) d else "$t · $d"
            }
        }) { chooseCountdown() }

        header("DIVERS")
        addRow("Tout réinitialiser", { "Revenir aux réglages d'origine" }) { confirmReset() }

        refreshAll()
        list.post { firstRow?.requestFocus() }
    }

    private fun header(text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0x99FFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        t.letterSpacing = 0.15f
        t.setPadding(dp(4), dp(14), 0, dp(2))
        list.addView(t)
    }

    private fun addRow(title: String, value: () -> String, onClick: () -> Unit) {
        val anim = Prefs.anim(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.isFocusable = true
        row.background = Ui.focusDrawable(this, Prefs.accent(this), Prefs.TILE_RADIUS[Prefs.radius(this)] + 4f, false, 4f, 0x26FFFFFF, 0f)
        row.setPadding(dp(18), dp(9), dp(18), dp(9))
        val lp = LinearLayout.LayoutParams(dp(560), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(3), 0, dp(3))
        row.layoutParams = lp

        val t = TextView(this)
        t.text = title
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        val v = TextView(this)
        v.setTextColor(0x99FFFFFF.toInt())
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        row.addView(t)
        row.addView(v)
        row.setOnClickListener { r -> Ui.press(r, 1f, anim) { onClick() } }
        refreshers.add { v.text = value() }
        list.addView(row)
        if (firstRow == null) firstRow = row
    }

    // ---- Dialogues génériques ----
    private fun chooseOne(title: String, names: Array<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(names, current) { d, i ->
                onPick(i)
                refreshAll()
                d.dismiss()
            }.show()
    }

    // ---- Fond d'écran ----
    private fun chooseWallpaper() {
        val labels = Wallpapers.CHOICES.map { it.second }.toMutableList()
        labels.add("Mon image (stockage / clé USB)…")
        AlertDialog.Builder(this)
            .setTitle("Fond d'écran")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < Wallpapers.CHOICES.size) {
                    Prefs.setWallpaper(this, Wallpapers.CHOICES[i].first)
                    refreshAll()
                } else {
                    pickCustomImage()
                }
            }.show()
    }

    private fun pickCustomImage() {
        try {
            pickDoc.launch(arrayOf("image/*"))
        } catch (e: ActivityNotFoundException) {
            try {
                pickGet.launch("image/*")
            } catch (e2: ActivityNotFoundException) {
                toast("Aucun explorateur de fichiers sur cette TV. Installe une appli de fichiers (ex. X-plore, Files) puis réessaie.")
            }
        }
    }

    private fun saveWallpaper(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) {
                    runOnUiThread { toast("Image illisible") }
                    return@Thread
                }
                File(filesDir, "wallpaper_custom.jpg").outputStream().use {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
                }
                Prefs.setWallpaper(this, "custom")
                runOnUiThread { refreshAll(); toast("Fond d'écran enregistré") }
            } catch (e: Exception) {
                runOnUiThread { toast("Impossible de lire cette image") }
            }
        }.start()
    }

    // ---- Prénom ----
    private fun chooseName() {
        val input = EditText(this)
        input.hint = "Ton prénom"
        input.setSingleLine()
        input.setText(Prefs.userName(this))
        AlertDialog.Builder(this)
            .setTitle("Prénom")
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                Prefs.setUserName(this, input.text.toString().trim())
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---- Widgets / raccourcis ----
    private fun chooseWidgets() {
        val cur = Prefs.widgets(this)
        val state = BooleanArray(Prefs.WIDGETS.size) { Prefs.WIDGETS[it].first in cur }
        AlertDialog.Builder(this)
            .setTitle("Widgets affichés")
            .setMultiChoiceItems(Prefs.WIDGETS.map { it.second }.toTypedArray(), state) { _, i, c -> state[i] = c }
            .setPositiveButton("OK") { _, _ ->
                Prefs.setWidgets(this, Prefs.WIDGETS.filterIndexed { i, _ -> state[i] }.map { it.first }.toSet())
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun chooseShortcuts() {
        val cur = Prefs.shortcuts(this)
        val state = BooleanArray(Prefs.SHORTCUTS.size) { Prefs.SHORTCUTS[it].key in cur }
        val names = Prefs.SHORTCUTS.map { "${it.icon}  ${it.label}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Raccourcis (le bouton 🎨 est toujours là)")
            .setMultiChoiceItems(names, state) { _, i, c -> state[i] = c }
            .setPositiveButton("OK") { _, _ ->
                Prefs.setShortcuts(this, Prefs.SHORTCUTS.filterIndexed { i, _ -> state[i] }.map { it.key })
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---- Applis du bas ----
    private fun chooseApps() {
        val pm = packageManager
        var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var infos = pm.queryIntentActivities(intent, 0)
        if (infos.isEmpty()) {
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            infos = pm.queryIntentActivities(intent, 0)
        }
        val apps = infos
            .filter { it.activityInfo.packageName != packageName }
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val current = Prefs.favorites(this) ?: Prefs.defaultFavorites(pm)
        val checked = BooleanArray(apps.size) { apps[it].first in current }

        AlertDialog.Builder(this)
            .setTitle("Applications du bas")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                val selected = apps.filterIndexed { i, _ -> checked[i] }.map { it.first }
                val ordered = current.filter { it in selected } + selected.filter { it !in current }
                Prefs.setFavorites(this, ordered)
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---- Ville ----
    private fun chooseCity() {
        val input = EditText(this)
        input.hint = "Nom de la ville"
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Ville de la météo")
            .setView(input)
            .setPositiveButton("Rechercher") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun searchCity(q: String) {
        if (q.isEmpty()) return
        Thread {
            try {
                val url = URL(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(q, "UTF-8") + "&count=6&language=fr&format=json"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
                val res = json.optJSONArray("results")
                runOnUiThread {
                    if (res == null || res.length() == 0) toast("Ville introuvable") else showCities(res)
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Recherche impossible (connexion ?)") }
            }
        }.start()
    }

    private fun showCities(res: JSONArray) {
        val names = Array(res.length()) { i ->
            val o = res.getJSONObject(i)
            listOf(o.optString("name"), o.optString("admin1"), o.optString("country"))
                .filter { it.isNotBlank() }.joinToString(", ")
        }
        AlertDialog.Builder(this)
            .setTitle("Choisis ta ville")
            .setItems(names) { _, i ->
                val o = res.getJSONObject(i)
                Prefs.setCity(this, o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude"))
                refreshAll()
            }.show()
    }

    // ---- Compte à rebours ----
    private fun chooseCountdown() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), 0)
        val t = EditText(this)
        t.hint = "Titre (ex. Vacances)"
        t.setSingleLine()
        t.setText(Prefs.cdTitle(this))
        val d = EditText(this)
        d.hint = "Date : JJ/MM/AAAA"
        d.setSingleLine()
        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
        fmt.isLenient = false
        val cur = Prefs.cdDate(this)
        if (cur != 0L) d.setText(fmt.format(Date(cur)))
        box.addView(t)
        box.addView(d)

        AlertDialog.Builder(this)
            .setTitle("Compte à rebours")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val ms: Long? = try {
                    fmt.parse(d.text.toString().trim())?.time
                } catch (e: Exception) {
                    null
                }
                if (ms == null) {
                    toast("Date invalide (format JJ/MM/AAAA)")
                } else {
                    Prefs.setCountdown(this, t.text.toString().trim(), ms)
                    refreshAll()
                }
            }
            .setNeutralButton("Supprimer") { _, _ ->
                Prefs.setCountdown(this, "", 0L)
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Tout réinitialiser ?")
            .setMessage("Tous les réglages reviendront à leur valeur d'origine.")
            .setPositiveButton("Réinitialiser") { _, _ ->
                Prefs.reset(this)
                refreshAll()
                toast("Réglages d'origine rétablis")
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
