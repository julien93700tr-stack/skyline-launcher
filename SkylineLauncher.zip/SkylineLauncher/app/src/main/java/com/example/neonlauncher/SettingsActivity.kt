package com.example.neonlauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class SettingsActivity : AppCompatActivity() {

    private val refreshers = mutableListOf<() -> Unit>()
    private lateinit var list: LinearLayout

    private val pickDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }
    private val pickGet = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveWallpaper(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun refreshAll() = refreshers.forEach { it() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundResource(R.drawable.bg_gradient)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(48), dp(28), dp(48), dp(28))
        scroll.addView(list)
        setContentView(scroll)

        val title = TextView(this)
        title.text = "Personnaliser"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
        list.addView(title)
        val hint = TextView(this)
        hint.text = "OK pour modifier un réglage · Retour pour revenir à l'accueil"
        hint.setTextColor(0x99FFFFFF.toInt())
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        hint.setPadding(0, dp(4), 0, dp(14))
        list.addView(hint)

        addRow("Fond d'écran", { Wallpapers.label(Prefs.wallpaper(this)) }) { chooseWallpaper() }
        addRow("Ville de la météo", { Prefs.city(this) }) { chooseCity() }
        addRow("Applications du bas", {
            val n = (Prefs.favorites(this) ?: Prefs.defaultFavorites(packageManager)).size
            "$n application(s)"
        }) { chooseApps() }
        addRow("Taille de l'heure", { Prefs.CLOCK_NAMES[Prefs.clockIndex(this)] }) { chooseClock() }
        addRow("Assombrissement du fond", { Prefs.DIM_NAMES[Prefs.dim(this)] }) { chooseDim() }
        addRow("Éléments affichés", {
            listOfNotNull(
                if (Prefs.showCalendar(this)) "Calendrier" else null,
                if (Prefs.showWeather(this)) "Météo" else null
            ).joinToString(", ").ifEmpty { "Aucun" }
        }) { chooseElements() }
        addRow("Tout réinitialiser", { "Revenir aux réglages d'origine" }) { confirmReset() }

        refreshAll()
        list.post { list.getChildAt(2)?.requestFocus() }
    }

    private fun addRow(title: String, value: () -> String, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundResource(R.drawable.tile_bg)
        row.isFocusable = true
        row.setPadding(dp(18), dp(10), dp(18), dp(10))
        val lp = LinearLayout.LayoutParams(dp(520), ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(4), 0, dp(4))
        row.layoutParams = lp

        val t = TextView(this)
        t.text = title
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        val v = TextView(this)
        v.setTextColor(0x99FFFFFF.toInt())
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        row.addView(t)
        row.addView(v)
        row.setOnClickListener { onClick() }
        refreshers.add { v.text = value() }
        list.addView(row)
    }

    // ---- Fond d'écran ----
    private fun chooseWallpaper() {
        val labels = Wallpapers.CHOICES.map { it.second }.toMutableList()
        labels.add("Mon image (stockage / clé USB)…")
        AlertDialog.Builder(this)
            .setTitle("Fond d'écran")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i < Wallpapers.CHOICES.size) {
                    Prefs.setWallpaper(this, Wallpapers.CHOICES[i].first)
                    refreshAll()
                } else {
                    pickCustomImage()
                }
            }.show()
    }

    private fun pickCustomImage() {
        try {
            pickDoc.launch(arrayOf("image/*"))
        } catch (e: ActivityNotFoundException) {
            try {
                pickGet.launch("image/*")
            } catch (e2: ActivityNotFoundException) {
                toast("Aucun explorateur de fichiers sur cette TV. Installe une appli de fichiers (ex. X-plore, Files) puis réessaie.")
            }
        }
    }

    private fun saveWallpaper(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) {
                    runOnUiThread { toast("Image illisible") }
                    return@Thread
                }
                File(filesDir, "wallpaper_custom.jpg").outputStream().use {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, it)
                }
                Prefs.setWallpaper(this, "custom")
                runOnUiThread { refreshAll(); toast("Fond d'écran enregistré") }
            } catch (e: Exception) {
                runOnUiThread { toast("Impossible de lire cette image") }
            }
        }.start()
    }

    // ---- Ville ----
    private fun chooseCity() {
        val input = EditText(this)
        input.hint = "Nom de la ville"
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Ville de la météo")
            .setView(input)
            .setPositiveButton("Rechercher") { _, _ -> searchCity(input.text.toString().trim()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun searchCity(q: String) {
        if (q.isEmpty()) return
        Thread {
            try {
                val url = URL(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" +
                        URLEncoder.encode(q, "UTF-8") + "&count=6&language=fr&format=json"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
                val res = json.optJSONArray("results")
                runOnUiThread {
                    if (res == null || res.length() == 0) toast("Ville introuvable") else showCities(res)
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Recherche impossible (connexion ?)") }
            }
        }.start()
    }

    private fun showCities(res: JSONArray) {
        val names = Array(res.length()) { i ->
            val o = res.getJSONObject(i)
            listOf(o.optString("name"), o.optString("admin1"), o.optString("country"))
                .filter { it.isNotBlank() }.joinToString(", ")
        }
        AlertDialog.Builder(this)
            .setTitle("Choisis ta ville")
            .setItems(names) { _, i ->
                val o = res.getJSONObject(i)
                Prefs.setCity(this, o.getString("name"), o.getDouble("latitude"), o.getDouble("longitude"))
                refreshAll()
            }.show()
    }

    // ---- Applis du bas ----
    private fun chooseApps() {
        val pm = packageManager
        var intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var infos = pm.queryIntentActivities(intent, 0)
        if (infos.isEmpty()) {
            intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            infos = pm.queryIntentActivities(intent, 0)
        }
        val apps = infos
            .filter { it.activityInfo.packageName != packageName }
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val current = Prefs.favorites(this) ?: Prefs.defaultFavorites(pm)
        val checked = BooleanArray(apps.size) { apps[it].first in current }

        AlertDialog.Builder(this)
            .setTitle("Applications du bas")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                val selected = apps.filterIndexed { i, _ -> checked[i] }.map { it.first }
                val ordered = current.filter { it in selected } + selected.filter { it !in current }
                Prefs.setFavorites(this, ordered)
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---- Heure / assombrissement / éléments ----
    private fun chooseClock() {
        AlertDialog.Builder(this)
            .setTitle("Taille de l'heure")
            .setSingleChoiceItems(Prefs.CLOCK_NAMES, Prefs.clockIndex(this)) { d, i ->
                Prefs.setClockIndex(this, i)
                refreshAll()
                d.dismiss()
            }.show()
    }

    private fun chooseDim() {
        AlertDialog.Builder(this)
            .setTitle("Assombrissement du fond")
            .setSingleChoiceItems(Prefs.DIM_NAMES, Prefs.dim(this)) { d, i ->
                Prefs.setDim(this, i)
                refreshAll()
                d.dismiss()
            }.show()
    }

    private fun chooseElements() {
        val state = booleanArrayOf(Prefs.showCalendar(this), Prefs.showWeather(this))
        AlertDialog.Builder(this)
            .setTitle("Éléments affichés")
            .setMultiChoiceItems(arrayOf("Calendrier", "Météo"), state) { _, i, c -> state[i] = c }
            .setPositiveButton("OK") { _, _ ->
                Prefs.setShow(this, state[0], state[1])
                refreshAll()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Tout réinitialiser ?")
            .setMessage("Fond d'écran, ville, applications et affichage reviendront aux réglages d'origine.")
            .setPositiveButton("Réinitialiser") { _, _ ->
                Prefs.reset(this)
                refreshAll()
                toast("Réglages d'origine rétablis")
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
