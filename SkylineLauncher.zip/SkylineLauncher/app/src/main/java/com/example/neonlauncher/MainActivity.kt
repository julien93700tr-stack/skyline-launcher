package com.example.neonlauncher

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val fr = Locale.FRANCE

    private lateinit var wallpaper: ImageView
    private lateinit var overlay: View
    private lateinit var dateView: TextView
    private lateinit var clock: TextView
    private lateinit var calBlock: View
    private lateinit var weatherBlock: View
    private lateinit var cityView: TextView
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private lateinit var tempView: TextView
    private lateinit var forecast: LinearLayout
    private lateinit var quick: LinearLayout
    private lateinit var favorites: LinearLayout
    private lateinit var favTitle: TextView
    private var shownDay = -1

    private val tick = object : Runnable {
        override fun run() {
            refreshDate()
            ui.postDelayed(this, 30_000)
        }
    }
    private val weatherTick = object : Runnable {
        override fun run() {
            fetchWeather()
            ui.postDelayed(this, 30 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wallpaper = findViewById(R.id.wallpaper)
        overlay = findViewById(R.id.overlay)
        dateView = findViewById(R.id.date)
        clock = findViewById(R.id.clock)
        calBlock = findViewById(R.id.calBlock)
        weatherBlock = findViewById(R.id.weatherBlock)
        cityView = findViewById(R.id.city)
        calTitle = findViewById(R.id.calTitle)
        calGrid = findViewById(R.id.calGrid)
        tempView = findViewById(R.id.temp)
        forecast = findViewById(R.id.forecast)
        quick = findViewById(R.id.quick)
        favorites = findViewById(R.id.favorites)
        favTitle = findViewById(R.id.favTitle)

        // L'heure s'estompe vers le bas
        clock.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val h = (bottom - top).toFloat()
            (v as TextView).paint.shader = LinearGradient(
                0f, 0f, 0f, h,
                Color.argb(200, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            v.invalidate()
        }

        buildQuickSettings()
    }

    override fun onResume() {
        super.onResume()
        applyPrefs()
        shownDay = -1
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
        ui.post(tick)
        ui.post(weatherTick)
        buildFavorites()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
    }

    // Touche MENU de la télécommande = ouvrir Personnaliser
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyPrefs() {
        Wallpapers.show(this, wallpaper, Prefs.wallpaper(this))
        overlay.alpha = Prefs.DIM_LEVELS[Prefs.dim(this)]
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.clockSp().toFloat())
        calBlock.visibility = if (Prefs.showCalendar(this)) View.VISIBLE else View.GONE
        weatherBlock.visibility = if (Prefs.showWeather(this)) View.VISIBLE else View.GONE
        cityView.text = Prefs.city(this)
    }

    private fun Prefs.clockSp(): Int = Prefs.CLOCK_SIZES[Prefs.clockIndex(this@MainActivity)]

    // ---------- Date + calendrier ----------
    private fun refreshDate() {
        val now = Calendar.getInstance(fr)
        dateView.text = SimpleDateFormat("EEE d MMM", fr).format(now.time)
            .replaceFirstChar { it.uppercase() }
        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != shownDay) {
            shownDay = day
            buildCalendar(now)
        }
    }

    private fun buildCalendar(now: Calendar) {
        calTitle.text = SimpleDateFormat("MMMM yyyy", fr).format(now.time).uppercase(fr)
        calGrid.removeAllViews()
        val cell = dp(24)

        fun addCell(text: String, dim: Boolean, today: Boolean) {
            val tv = TextView(this)
            tv.text = text
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            tv.setTextColor(
                if (today) Color.BLACK else if (dim) Color.argb(153, 255, 255, 255) else Color.WHITE
            )
            if (today) tv.setBackgroundResource(R.drawable.today_bg)
            val lp = GridLayout.LayoutParams()
            lp.width = cell
            lp.height = cell
            tv.layoutParams = lp
            calGrid.addView(tv)
        }

        for (d in listOf("L", "M", "M", "J", "V", "S", "D")) addCell(d, true, false)
        val first = now.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        repeat(offset) { addCell("", false, false) }
        val today = now.get(Calendar.DAY_OF_MONTH)
        for (d in 1..now.getActualMaximum(Calendar.DAY_OF_MONTH)) {
            addCell(d.toString(), false, d == today)
        }
    }

    // ---------- Raccourcis ----------
    private fun buildQuickSettings() {
        val items = listOf(
            "📶" to Settings.ACTION_WIFI_SETTINGS,
            "🎧" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "🔊" to Settings.ACTION_SOUND_SETTINGS,
            "📺" to Settings.ACTION_DISPLAY_SETTINGS,
            "⚙️" to Settings.ACTION_SETTINGS
        )
        for ((icon, action) in items) {
            val v = layoutInflater.inflate(R.layout.item_round, quick, false) as TextView
            v.text = icon
            v.setOnClickListener { openSettings(action) }
            focusScale(v, 1.15f)
            quick.addView(v)
        }
        // Bouton Personnaliser (le launcher lui-même)
        val perso = layoutInflater.inflate(R.layout.item_round, quick, false) as TextView
        perso.text = "🎨"
        perso.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        focusScale(perso, 1.15f)
        quick.addView(perso)
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Applis du bas ----------
    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    private fun addTile(name: String, drawable: Drawable?, isBanner: Boolean, onClick: () -> Unit): View {
        val item = layoutInflater.inflate(R.layout.item_fav, favorites, false)
        val tile = item.findViewById<View>(R.id.tile)
        val img = item.findViewById<ImageView>(R.id.icon)
        val label = item.findViewById<TextView>(R.id.label)
        img.setImageDrawable(drawable)
        if (isBanner) {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setPadding(0, 0, 0, 0)
        } else {
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            img.setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        label.text = name
        tile.setOnClickListener { onClick() }
        tile.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.12f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            label.visibility = if (focused) View.VISIBLE else View.INVISIBLE
            if (focused) favTitle.text = name
        }
        favorites.addView(item)
        return tile
    }

    private fun buildFavorites() {
        favorites.removeAllViews()
        var firstTile: View? = null
        val pkgs = Prefs.favorites(this) ?: Prefs.defaultFavorites(packageManager)
        for (pkg in pkgs) {
            val intent = launchIntentFor(pkg) ?: continue
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                continue
            }
            val ai = intent.resolveActivityInfo(packageManager, 0)
            val banner: Drawable? = ai?.loadBanner(packageManager)
                ?: ai?.applicationInfo?.loadBanner(packageManager)
            val tile = if (banner != null) {
                addTile(name, banner, true) { startActivity(intent) }
            } else {
                addTile(name, packageManager.getApplicationIcon(pkg), false) { startActivity(intent) }
            }
            if (firstTile == null) firstTile = tile
        }
        val allTile = addTile(
            "Toutes les applis",
            ContextCompat.getDrawable(this, R.drawable.ic_apps),
            false
        ) { startActivity(Intent(this, AllAppsActivity::class.java)) }

        val focusTile = firstTile ?: allTile
        favorites.post { focusTile.requestFocus() }
    }

    private fun focusScale(v: View, scale: Float) {
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) scale else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
    }

    // ---------- Météo (Open-Meteo) ----------
    private fun fetchWeather() {
        val lat = Prefs.lat(this)
        val lon = Prefs.lon(this)
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=5"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
                runOnUiThread { showWeather(json) }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun showWeather(j: JSONObject) {
        val cur = j.getJSONObject("current")
        tempView.text = "${Math.round(cur.getDouble("temperature_2m"))}° ${emoji(cur.getInt("weather_code"))}"

        val daily = j.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val codes = daily.getJSONArray("weather_code")
        val maxs = daily.getJSONArray("temperature_2m_max")
        val mins = daily.getJSONArray("temperature_2m_min")
        val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayFmt = SimpleDateFormat("EEE", fr)

        forecast.removeAllViews()
        for (i in 1 until minOf(5, dates.length())) {
            val dayName = dayFmt.format(parse.parse(dates.getString(i))!!)
                .replace(".", "").replaceFirstChar { it.uppercase() }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label(dayName, 44, Gravity.START, Color.WHITE))
            row.addView(label(emoji(codes.getInt(i)), 28, Gravity.CENTER, Color.WHITE))
            row.addView(label("${Math.round(mins.getDouble(i))}", 42, Gravity.END, Color.argb(153, 255, 255, 255)))
            row.addView(label("${Math.round(maxs.getDouble(i))}°", 42, Gravity.END, Color.WHITE))
            forecast.addView(row)
        }
    }

    private fun label(text: String, widthDp: Int, gravity: Int, color: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = gravity
        tv.setTextColor(color)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        tv.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(20))
        return tv
    }

    private fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1 -> "🌤️"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
