package com.example.neonlauncher

import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val fr = Locale.FRANCE

    private lateinit var root: View
    private lateinit var wallpaper: ImageView
    private lateinit var overlay: View
    private lateinit var greeting: TextView
    private lateinit var clock: TextClock
    private lateinit var calCard: View
    private lateinit var weatherCard: View
    private lateinit var shortcutsCard: View
    private lateinit var rightCol: View
    private lateinit var cdCard: View
    private lateinit var storageCard: View
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private lateinit var tempView: TextView
    private lateinit var condView: TextView
    private lateinit var cityView: TextView
    private lateinit var detailsView: TextView
    private lateinit var forecast: LinearLayout
    private lateinit var shortcutGrid: GridLayout
    private lateinit var shortcutHint: TextView
    private lateinit var cdBig: TextView
    private lateinit var cdTitle: TextView
    private lateinit var storageText: TextView
    private lateinit var storageSub: TextView
    private lateinit var bar: View
    private lateinit var barUsed: View
    private lateinit var barFree: View
    private lateinit var favorites: LinearLayout
    private lateinit var favTitle: TextView
    private var shownDay = -1

    private val tick = object : Runnable {
        override fun run() {
            refreshDate()
            ui.postDelayed(this, 30_000)
        }
    }
    private val weatherTick = object : Runnable {
        override fun run() {
            fetchWeather()
            ui.postDelayed(this, 30 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        wallpaper = findViewById(R.id.wallpaper)
        overlay = findViewById(R.id.overlay)
        greeting = findViewById(R.id.greeting)
        clock = findViewById(R.id.clock)
        calCard = findViewById(R.id.calCard)
        weatherCard = findViewById(R.id.weatherCard)
        shortcutsCard = findViewById(R.id.shortcutsCard)
        rightCol = findViewById(R.id.rightCol)
        cdCard = findViewById(R.id.cdCard)
        storageCard = findViewById(R.id.storageCard)
        calTitle = findViewById(R.id.calTitle)
        calGrid = findViewById(R.id.calGrid)
        tempView = findViewById(R.id.temp)
        condView = findViewById(R.id.cond)
        cityView = findViewById(R.id.city)
        detailsView = findViewById(R.id.details)
        forecast = findViewById(R.id.forecast)
        shortcutGrid = findViewById(R.id.shortcutGrid)
        shortcutHint = findViewById(R.id.shortcutHint)
        cdBig = findViewById(R.id.cdBig)
        cdTitle = findViewById(R.id.cdTitle)
        storageText = findViewById(R.id.storageText)
        storageSub = findViewById(R.id.storageSub)
        bar = findViewById(R.id.bar)
        barUsed = findViewById(R.id.barUsed)
        barFree = findViewById(R.id.barFree)
        favorites = findViewById(R.id.favorites)
        favTitle = findViewById(R.id.favTitle)

        // L'heure s'estompe vers le bas
        clock.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val h = (bottom - top).toFloat()
            (v as TextView).paint.shader = LinearGradient(
                0f, 0f, 0f, h,
                Color.argb(215, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            v.invalidate()
        }
    }

    override fun onResume() {
        super.onResume()
        applyPrefs()
        shownDay = -1
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
        ui.post(tick)
        ui.post(weatherTick)
        buildShortcuts()
        buildFavorites()
        updateCountdown()
        updateStorage()
        playEntrance()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
    }

    // Touche MENU de la télécommande = Personnaliser
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            openScreen(SettingsActivity::class.java)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun dp(v: Int) = Ui.px(this, v)

    private fun openScreen(cls: Class<*>) {
        startActivity(Intent(this, cls))
        if (Prefs.anim(this) != 2) overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    // ---------- Réglages -> affichage ----------
    private fun applyPrefs() {
        Wallpapers.show(this, wallpaper, Prefs.wallpaper(this))
        overlay.alpha = Prefs.DIM_LEVELS[Prefs.dim(this)]
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.CLOCK_SIZES[Prefs.clockIndex(this)].toFloat())
        val f = if (Prefs.clock24(this)) "HH:mm" else "h:mm"
        clock.format12Hour = f
        clock.format24Hour = f
        cityView.text = Prefs.city(this)

        val w = Prefs.widgets(this)
        calCard.visibility = vis("calendar" in w)
        weatherCard.visibility = vis("weather" in w)
        shortcutsCard.visibility = vis("shortcuts" in w)
        cdCard.visibility = vis("countdown" in w)
        storageCard.visibility = vis("storage" in w)
        rightCol.visibility = vis("countdown" in w || "storage" in w)

        for (c in listOf(calCard, weatherCard, shortcutsCard, cdCard, storageCard)) {
            c.background = Ui.card(this)
        }
        bar.background = Ui.roundRect(this, 0x33FFFFFF, 3f)
        barUsed.background = Ui.roundRect(this, Prefs.accent(this), 3f)
    }

    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    // ---------- Animation d'entrée ----------
    private fun playEntrance() {
        if (Prefs.anim(this) != 0) {
            root.animate().cancel()
            root.alpha = 1f
            for (c in listOf(calCard, weatherCard, shortcutsCard, cdCard, storageCard)) {
                c.alpha = 1f
                c.translationY = 0f
            }
            return
        }
        root.animate().cancel()
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(320).start()
        var i = 0
        for (c in listOf(calCard, weatherCard, shortcutsCard, cdCard, storageCard)) {
            if (c.visibility != View.VISIBLE) continue
            c.alpha = 0f
            c.translationY = dp(14).toFloat()
            c.animate().alpha(1f).translationY(0f).setStartDelay(70L * i).setDuration(340).start()
            i++
        }
    }

    // ---------- Date, accueil, calendrier ----------
    private fun refreshDate() {
        val now = Calendar.getInstance(fr)
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val hello = when {
            hour in 5..11 -> "Bonjour"
            hour in 12..17 -> "Bon après-midi"
            else -> "Bonsoir"
        }
        val name = Prefs.userName(this)
        val date = SimpleDateFormat("EEEE d MMMM", fr).format(now.time)
            .replaceFirstChar { it.uppercase() }
        greeting.text = (if (name.isBlank()) hello else "$hello $name") + "  ·  " + date

        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != shownDay) {
            shownDay = day
            buildCalendar(now)
            updateCountdown()
        }
    }

    private fun buildCalendar(now: Calendar) {
        calTitle.text = SimpleDateFormat("MMMM yyyy", fr).format(now.time).uppercase(fr)
        calGrid.removeAllViews()
        val cell = dp(21)
        val accent = Prefs.accent(this)

        fun addCell(text: String, dim: Boolean, today: Boolean) {
            val tv = TextView(this)
            tv.text = text
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            tv.setTextColor(
                if (today) Color.BLACK else if (dim) Color.argb(153, 255, 255, 255) else Color.WHITE
            )
            if (today) {
                tv.background = Ui.disc(this, accent)
                tv.setTypeface(tv.typeface, android.graphics.Typeface.BOLD)
            }
            val lp = GridLayout.LayoutParams()
            lp.width = cell
            lp.height = cell
            tv.layoutParams = lp
            calGrid.addView(tv)
        }

        for (d in listOf("L", "M", "M", "J", "V", "S", "D")) addCell(d, true, false)
        val first = now.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        repeat(offset) { addCell("", false, false) }
        val today = now.get(Calendar.DAY_OF_MONTH)
        for (d in 1..now.getActualMaximum(Calendar.DAY_OF_MONTH)) {
            addCell(d.toString(), false, d == today)
        }
    }

    // ---------- Raccourcis ----------
    private fun buildShortcuts() {
        shortcutGrid.removeAllViews()
        shortcutHint.text = " "
        for (key in Prefs.shortcuts(this)) {
            val s = Prefs.SHORTCUTS.firstOrNull { it.key == key } ?: continue
            addShortcut(s.icon, s.label) { openSystemSettings(s.action) }
        }
        addShortcut("🎨", "Personnaliser") { openScreen(SettingsActivity::class.java) }
    }

    private fun addShortcut(icon: String, label: String, onClick: () -> Unit) {
        val anim = Prefs.anim(this)
        val tv = TextView(this)
        tv.text = icon
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        tv.isFocusable = true
        tv.background = Ui.focusDrawable(this, Prefs.accent(this), 17f, true, 4f, 0x26FFFFFF, 4f)
        val lp = GridLayout.LayoutParams()
        lp.width = dp(34)
        lp.height = dp(34)
        lp.setMargins(dp(1), dp(1), dp(1), dp(1))
        tv.layoutParams = lp
        tv.setOnFocusChangeListener { v, focused ->
            Ui.focusScale(v, focused, 1.15f, anim)
            if (focused) shortcutHint.text = label
        }
        tv.setOnClickListener { v -> Ui.press(v, if (v.isFocused) 1.15f else 1f, anim) { onClick() } }
        shortcutGrid.addView(tv)
    }

    private fun openSystemSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Applications du bas ----------
    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    private fun launch(from: View, intent: Intent) {
        try {
            if (Prefs.anim(this) == 0) {
                val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                root.animate().alpha(0f).setDuration(260).start()
                startActivity(intent, opts.toBundle())
            } else {
                startActivity(intent)
            }
        } catch (e: Exception) {
            root.animate().cancel()
            root.alpha = 1f
        }
    }

    private fun addTile(
        name: String, drawable: Drawable?, banner: Boolean, index: Int, onClick: (View) -> Unit
    ): View {
        val item = layoutInflater.inflate(R.layout.item_fav, favorites, false)
        val tile = Ui.setupTile(this, item, name, drawable, banner, false,
            { focused -> if (focused) favTitle.text = name }, onClick)
        favorites.addView(item)
        if (Prefs.anim(this) == 0) {
            item.alpha = 0f
            item.translationY = dp(16).toFloat()
            item.animate().alpha(1f).translationY(0f)
                .setStartDelay(160L + 55L * index).setDuration(300).start()
        }
        return tile
    }

    private fun buildFavorites() {
        favorites.removeAllViews()
        favTitle.text = " "
        var first: View? = null
        var index = 0
        val pkgs = Prefs.favorites(this) ?: Prefs.defaultFavorites(packageManager)
        for (pkg in pkgs) {
            val intent = launchIntentFor(pkg) ?: continue
            val name = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                continue
            }
            val ai = intent.resolveActivityInfo(packageManager, 0)
            val banner: Drawable? = ai?.loadBanner(packageManager)
                ?: ai?.applicationInfo?.loadBanner(packageManager)
            val t = addTile(
                name, banner ?: packageManager.getApplicationIcon(pkg), banner != null, index
            ) { v -> launch(v, intent) }
            if (first == null) first = t
            index++
        }
        val all = addTile(
            "Toutes les applis", ContextCompat.getDrawable(this, R.drawable.ic_apps), false, index
        ) { openScreen(AllAppsActivity::class.java) }

        val focusTile = first ?: all
        favorites.post { focusTile.requestFocus() }
    }

    // ---------- Widgets : compte à rebours, stockage ----------
    private fun updateCountdown() {
        cdBig.setTextColor(Prefs.accent(this))
        val t = Prefs.cdDate(this)
        val title = Prefs.cdTitle(this)
        if (t == 0L) {
            cdBig.text = "—"
            cdTitle.text = "À configurer dans Personnaliser"
            return
        }
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        val diff = Math.round((t - c.timeInMillis) / 86_400_000.0).toInt()
        cdBig.text = when {
            diff > 0 -> "J-$diff"
            diff == 0 -> "Aujourd'hui"
            else -> "Terminé"
        }
        cdTitle.text = if (title.isBlank()) SimpleDateFormat("d MMM yyyy", fr).format(Date(t)) else title
    }

    private fun updateStorage() {
        try {
            val st = StatFs(Environment.getDataDirectory().path)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            val pct = ((total - free) * 100 / total).toInt().coerceIn(0, 100)
            storageText.text = String.format(fr, "%.1f Go libres", free / 1e9)
            storageSub.text = String.format(fr, "sur %.0f Go", total / 1e9)
            (barUsed.layoutParams as LinearLayout.LayoutParams).weight = pct.toFloat()
            (barFree.layoutParams as LinearLayout.LayoutParams).weight = (100 - pct).toFloat()
            bar.requestLayout()
        } catch (e: Exception) {
            storageText.text = "—"
        }
    }

    // ---------- Météo (Open-Meteo, gratuit, sans clé) ----------
    private fun fetchWeather() {
        val lat = Prefs.lat(this)
        val lon = Prefs.lon(this)
        val unit = if (Prefs.tempUnit(this) == 1) "&temperature_unit=fahrenheit" else ""
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=5" + unit
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
                runOnUiThread { showWeather(json) }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun showWeather(j: JSONObject) {
        val cur = j.getJSONObject("current")
        val code = cur.getInt("weather_code")
        val daily = j.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val codes = daily.getJSONArray("weather_code")
        val maxs = daily.getJSONArray("temperature_2m_max")
        val mins = daily.getJSONArray("temperature_2m_min")

        tempView.text = "${Math.round(cur.getDouble("temperature_2m"))}°"
        condView.text = "${emoji(code)} ${condition(code)}"
        cityView.text = "${Prefs.city(this)} · ↑${Math.round(maxs.getDouble(0))}° ↓${Math.round(mins.getDouble(0))}°"
        detailsView.text = "Ressenti ${Math.round(cur.getDouble("apparent_temperature"))}° · " +
            "${Math.round(cur.getDouble("relative_humidity_2m"))} % · " +
            "${Math.round(cur.getDouble("wind_speed_10m"))} km/h"

        val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayFmt = SimpleDateFormat("EEE", fr)
        forecast.removeAllViews()
        for (i in 1 until minOf(5, dates.length())) {
            val dayName = dayFmt.format(parse.parse(dates.getString(i))!!)
                .replace(".", "").replaceFirstChar { it.uppercase() }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label(dayName, 52, Gravity.START, Color.WHITE))
            row.addView(label(emoji(codes.getInt(i)), 30, Gravity.CENTER, Color.WHITE))
            row.addView(label("${Math.round(mins.getDouble(i))}°", 48, Gravity.END, Color.argb(153, 255, 255, 255)))
            row.addView(label("${Math.round(maxs.getDouble(i))}°", 48, Gravity.END, Color.WHITE))
            forecast.addView(row)
        }
    }

    private fun label(text: String, widthDp: Int, gravity: Int, color: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = gravity
        tv.setTextColor(color)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        tv.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(17))
        return tv
    }

    private fun condition(code: Int): String = when (code) {
        0 -> "Ciel dégagé"
        1 -> "Peu nuageux"
        2 -> "Éclaircies"
        3 -> "Couvert"
        45, 48 -> "Brouillard"
        in 51..57 -> "Bruine"
        in 61..67 -> "Pluie"
        in 71..77 -> "Neige"
        in 80..82 -> "Averses"
        85, 86 -> "Averses de neige"
        in 95..99 -> "Orage"
        else -> "Variable"
    }

    private fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1 -> "🌤️"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
