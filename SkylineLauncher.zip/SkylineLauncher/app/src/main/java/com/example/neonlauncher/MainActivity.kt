package com.example.neonlauncher

import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** ====== RÉGLAGES À MODIFIER ====== */
object Config {
    const val CITY = "Paris"
    const val LAT = 48.8566
    const val LON = 2.3522

    // Applis du bas : nom affiché -> packages possibles (le premier installé est utilisé)
    val FAVORITES = listOf(
        "YouTube" to listOf("com.google.android.youtube.tv", "com.liskovsoft.smarttubetv"),
        "Netflix" to listOf("com.netflix.ninja"),
        "Prime Video" to listOf("com.amazon.amazonvideo.livingroom"),
        "Disney+" to listOf("com.disney.disneyplus"),
        "Spotify" to listOf("com.spotify.tv.android")
    )
}

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private val fr = Locale.FRANCE

    private lateinit var dateView: TextView
    private lateinit var clock: TextView
    private lateinit var calTitle: TextView
    private lateinit var calGrid: GridLayout
    private lateinit var tempView: TextView
    private lateinit var forecast: LinearLayout
    private lateinit var quick: LinearLayout
    private lateinit var favorites: LinearLayout
    private var shownDay = -1

    private val tick = object : Runnable {
        override fun run() {
            refreshDate()
            ui.postDelayed(this, 30_000)
        }
    }
    private val weatherTick = object : Runnable {
        override fun run() {
            fetchWeather()
            ui.postDelayed(this, 30 * 60_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dateView = findViewById(R.id.date)
        clock = findViewById(R.id.clock)
        calTitle = findViewById(R.id.calTitle)
        calGrid = findViewById(R.id.calGrid)
        tempView = findViewById(R.id.temp)
        forecast = findViewById(R.id.forecast)
        quick = findViewById(R.id.quick)
        favorites = findViewById(R.id.favorites)
        findViewById<TextView>(R.id.city).text = Config.CITY

        // L'heure s'estompe vers le bas, comme sur l'image
        clock.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val h = (bottom - top).toFloat()
            (v as TextView).paint.shader = LinearGradient(
                0f, 0f, 0f, h,
                Color.argb(200, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
            v.invalidate()
        }

        buildQuickSettings()
    }

    override fun onResume() {
        super.onResume()
        shownDay = -1
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
        ui.post(tick)
        ui.post(weatherTick)
        buildFavorites()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        ui.removeCallbacks(weatherTick)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Date + calendrier ----------
    private fun refreshDate() {
        val now = Calendar.getInstance(fr)
        dateView.text = SimpleDateFormat("EEE d MMM", fr).format(now.time)
            .replaceFirstChar { it.uppercase() }
        val day = now.get(Calendar.DAY_OF_YEAR)
        if (day != shownDay) {
            shownDay = day
            buildCalendar(now)
        }
    }

    private fun buildCalendar(now: Calendar) {
        calTitle.text = SimpleDateFormat("MMMM yyyy", fr).format(now.time).uppercase(fr)
        calGrid.removeAllViews()
        val cell = dp(24)

        fun addCell(text: String, dim: Boolean, today: Boolean) {
            val tv = TextView(this)
            tv.text = text
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            tv.setTextColor(
                if (today) Color.BLACK else if (dim) Color.argb(153, 255, 255, 255) else Color.WHITE
            )
            if (today) tv.setBackgroundResource(R.drawable.today_bg)
            val lp = GridLayout.LayoutParams()
            lp.width = cell
            lp.height = cell
            tv.layoutParams = lp
            calGrid.addView(tv)
        }

        for (d in listOf("L", "M", "M", "J", "V", "S", "D")) addCell(d, true, false)
        val first = now.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7  // semaine commençant le lundi
        repeat(offset) { addCell("", false, false) }
        val today = now.get(Calendar.DAY_OF_MONTH)
        for (d in 1..now.getActualMaximum(Calendar.DAY_OF_MONTH)) {
            addCell(d.toString(), false, d == today)
        }
    }

    // ---------- Paramètres de la TV ----------
    private fun buildQuickSettings() {
        val items = listOf(
            "📶" to Settings.ACTION_WIFI_SETTINGS,
            "🎧" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "🔊" to Settings.ACTION_SOUND_SETTINGS,
            "📺" to Settings.ACTION_DISPLAY_SETTINGS,
            "⚙️" to Settings.ACTION_SETTINGS
        )
        for ((icon, action) in items) {
            val v = layoutInflater.inflate(R.layout.item_round, quick, false) as TextView
            v.text = icon
            v.setOnClickListener { openSettings(action) }
            focusScale(v, 1.15f)
            quick.addView(v)
        }
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Applis du bas ----------
    private fun launchIntentFor(pkg: String): Intent? =
        packageManager.getLeanbackLaunchIntentForPackage(pkg)
            ?: packageManager.getLaunchIntentForPackage(pkg)

    private fun buildFavorites() {
        favorites.removeAllViews()
        for ((name, pkgs) in Config.FAVORITES) {
            val pkg = pkgs.firstOrNull { launchIntentFor(it) != null } ?: continue
            val v = layoutInflater.inflate(R.layout.item_fav, favorites, false)
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(packageManager.getApplicationIcon(pkg))
            v.findViewById<TextView>(R.id.label).text = name
            v.setOnClickListener { launchIntentFor(pkg)?.let { startActivity(it) } }
            focusScale(v, 1.12f)
            favorites.addView(v)
        }
        // Bouton "Toutes les apps"
        val all = layoutInflater.inflate(R.layout.item_fav, favorites, false)
        val icon = all.findViewById<ImageView>(R.id.icon)
        icon.setImageResource(R.drawable.ic_apps)
        icon.setPadding(dp(12), dp(12), dp(12), dp(12))
        all.findViewById<TextView>(R.id.label).text = "Toutes"
        all.setOnClickListener { startActivity(Intent(this, AllAppsActivity::class.java)) }
        focusScale(all, 1.12f)
        favorites.addView(all)

        favorites.post { favorites.getChildAt(0)?.requestFocus() }
    }

    private fun focusScale(v: View, scale: Float) {
        v.setOnFocusChangeListener { view, focused ->
            val s = if (focused) scale else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
    }

    // ---------- Météo (Open-Meteo, gratuit, sans clé) ----------
    private fun fetchWeather() {
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=${Config.LAT}&longitude=${Config.LON}" +
                        "&current=temperature_2m,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=Europe%2FParis&forecast_days=5"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                conn.disconnect()
                runOnUiThread { showWeather(json) }
            } catch (_: Exception) {
            }
        }.start()
    }

    private fun showWeather(j: JSONObject) {
        val cur = j.getJSONObject("current")
        tempView.text = "${Math.round(cur.getDouble("temperature_2m"))}° ${emoji(cur.getInt("weather_code"))}"

        val daily = j.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val codes = daily.getJSONArray("weather_code")
        val maxs = daily.getJSONArray("temperature_2m_max")
        val mins = daily.getJSONArray("temperature_2m_min")
        val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayFmt = SimpleDateFormat("EEE", fr)

        forecast.removeAllViews()
        for (i in 1 until minOf(5, dates.length())) {
            val dayName = dayFmt.format(parse.parse(dates.getString(i))!!)
                .replace(".", "").replaceFirstChar { it.uppercase() }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(label(dayName, 44, Gravity.START, Color.WHITE))
            row.addView(label(emoji(codes.getInt(i)), 28, Gravity.CENTER, Color.WHITE))
            row.addView(label("${Math.round(mins.getDouble(i))}", 42, Gravity.END, Color.argb(153, 255, 255, 255)))
            row.addView(label("${Math.round(maxs.getDouble(i))}°", 42, Gravity.END, Color.WHITE))
            forecast.addView(row)
        }
    }

    private fun label(text: String, widthDp: Int, gravity: Int, color: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = gravity
        tv.setTextColor(color)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        tv.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(20))
        return tv
    }

    private fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1 -> "🌤️"
        2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
